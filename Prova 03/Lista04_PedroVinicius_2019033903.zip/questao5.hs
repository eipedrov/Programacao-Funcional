fib 0 = 0 
fib 1 = 1
fib 2 = 1
fib n = fib (n - 1) + fib (n - 2)

restfib n m = (fib((fib n)) `mod` m)

--Input: restfib n m 